import { Router } from 'express';
import { loginRateLimit, authRateLimit } from '../../../middleware/rate-limit.middleware';
import { requireAuth } from '../../../middleware/auth.middleware';
import { validateBody } from '../../../middleware/validate.middleware';
import { AuthController } from '../controllers/auth.controller';
import { LoginDto, RefreshTokenDto, LogoutDto } from '../dto/auth.dto';

const router = Router();

/**
 * POST /auth/login
 * Thứ tự: loginRateLimit → validateBody → controller
 * Không cần token
 */
router.post(
  '/login',
  loginRateLimit,
  validateBody(LoginDto),
  AuthController.login,
);

/**
 * POST /auth/refresh
 * Thứ tự: authRateLimit → validateBody → controller
 * Không cần access token (dùng refresh token)
 */
router.post(
  '/refresh',
  authRateLimit,
  validateBody(RefreshTokenDto),
  AuthController.refresh,
);

/**
 * POST /auth/logout
 * Thứ tự: authRateLimit → requireAuth → validateBody → controller
 * Cần Bearer JWT hợp lệ
 */
router.post(
  '/logout',
  authRateLimit,
  requireAuth,
  validateBody(LogoutDto),
  AuthController.logout,
);

/**
 * GET /auth/me
 * Thứ tự: authRateLimit → requireAuth → controller
 * Cần Bearer JWT hợp lệ
 */
router.get(
  '/me',
  authRateLimit,
  requireAuth,
  AuthController.me,
);

export { router as authRouter };